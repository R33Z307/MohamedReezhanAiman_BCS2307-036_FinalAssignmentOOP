const prompt = require('prompt-sync')();

class UmrahPackage{
    constructor(name,email,packagetype,room,persons,ramadhan){
        name = this.name
        email = this.email
        packagetype = this.packagetype
        room = this.room
        persons = this.persons
        ramadhan = this.ramadhan
    }

    calTotal(roomprice){
        var total = (roomprice * persons) + (ramadhan * persons)
        return total
    }

    calDiscount(){
        if(persons>=3 && persons<5){
            var discount = total * 0.03
        }
        else if(persons>=5){
            var discount = total * 0.05
        }
        else{
            var discount = 0
        }

        return discount
    }

    calDeposit(){
        var deposit = (total - discount) * 0.3
        return deposit
    }

    calBalance(){
        var balance = total - discount - deposit
        return balance
    }
}

var jemaah1 = 0
var jemaah2 = 0
var jemaah3 = 0

do{
    var name = prompt("Please enter your name: ")
    var email = prompt("Please enter your email: ")
    
    console.log(`
                Umrah Package           
    =====================================
    
    1 - Pakej Umrah Ziarah Turki
    2 - Pakej Umrah Ziarah Switzerland
    3 - Pakej Umrah Ziarah Paris & London
    `)
    
    var packageopt = parseInt(prompt("Please enter your selection (1/2/3): "))
    
    console.log(`
                 Room Type           
    =====================================
    
    1 - Room for Two
    2 - Room for Three
    3 - Room for Four
    `)
    
    var roomopt = parseInt(prompt("Please enter room type (1/2/3): "))

    if(packageopt==1){
        var packagetype = 'Pakej Umrah Ziarah Turki'
        if(roomopt==1){
            var room = 'Room for Two'
            var roomprice = 12490
        }
        else if(roomopt==2){
            var room = 'Room for Three'
            var roomprice = 11490
        }
        else if(roomopt==3){
            var room = 'Room for Four'
            var roomprice = 10990
        }
        else{
            console.log('ERROR')
        }
    }
    else if(packageopt==2){
        var packagetype = 'Pakej Umrah Ziarah Switzerland'
        if(roomopt==1){
            var room = 'Room for Two'
            var roomprice = 14490
        }
        else if(roomopt==2){
            var room = 'Room for Three'
            var roomprice = 13490
        }
        else if(roomopt==3){
            var room = 'Room for Four'
            var roomprice = 12990
        }
        else{
            console.log('ERROR')
        }
    }
    else if(packageopt==3){
        var packagetype = 'Pakej Umrah Ziarah Paris & London'
        if(roomopt==1){
            var room = 'Room for Two'
            var roomprice = 15490
        }
        else if(roomopt==2){
            var room = 'Room for Three'
            var roomprice = 14490
        }
        else if(roomopt==3){
            var room = 'Room for Four'
            var roomprice = 13990
        }
        else{
            console.log('ERROR')
        }
    }
    else{
        console.log('ERROR')
    }

    var persons = parseInt(prompt("Please enter number of persons travelled: "))

    var ramadhanopt = prompt("Ramadhan season option (y/n): ")

    if(ramadhanopt=='y'){
        var ramadhan = 1200
    }
    else if(ramadhanopt=='n'){
        var ramadhan = 0
    }
    else{
        console.log('ERROR')
    }

    var umrah = new UmrahPackage(name,email,packagetype,room,persons,ramadhan)

    var total = umrah.calTotal(roomprice)
    var discount = umrah.calDiscount()
    var deposit = umrah.calDeposit()
    var balance = umrah.calBalance()

    console.log(`
Umrah Package: ${packagetype}
Room Type: ${room}
Total for ${persons} persons: RM${total.toFixed(2)}
Discount Amount: RM${discount.toFixed(2)}
Deposit upon Booking: RM${deposit.toFixed(2)}
Balance: RM${balance.toFixed(2)}
`)

if(packageopt==1){
    var jemaah1 = jemaah1 + persons
}
else if(packageopt==2){
    var jemaah2 = jemaah2 + persons
}
else if(packageopt==3){
    var jemaah3 = jemaah3 + persons
}
else{
    console.log('ERROR')
}

var option = prompt("Proceed with another booking? (y/n): ")

}while(option=='y')

console.log(`
Total Jemaah for Umrah Ziarah Turki: ${jemaah1}
Total Jemaah for Umrah Ziarah Switzerland: ${jemaah2}
Total Jemaah for Umrah Ziarah Paris & London: ${jemaah3}`)