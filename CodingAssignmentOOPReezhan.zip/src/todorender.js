const fs = require('fs');
const path = require('path');


const apiKey = '32804b24a847407391c53709241010'; 


document.getElementById('fetch-weather-btn').addEventListener('click', fetchWeatherData);

async function fetchWeatherData() {
    const location = document.getElementById('location-input').value; 
    if (!location) {
        alert('Please enter a location');
        return;
    }

    const response = await fetch(`https://api.weatherapi.com/v1/forecast.json?key=${apiKey}&q=${location}`);
    const data = await response.json();
    displayWeatherData(data);
    displayTravelRecommendations(data);
}

function displayWeatherData(data) {
    const weatherInfo = document.getElementById('weather-info');

    if (data.error) {
        weatherInfo.innerHTML = `<tr><td colspan="13">Error: ${data.error.message}</td></tr>`;
        return;
    }

    const locationName = data.location.name;
    const country = data.location.country;
    const localTime = data.location.localtime;
    const currentTemp = data.current.temp_c;
    const feelsLike = data.current.feelslike_c;
    const forecastTemp = `${data.current.temp_c}°C`;
    const sunrise = data.forecast.forecastday[0].astro.sunrise;
    const sunset = data.forecast.forecastday[0].astro.sunset;
    const iconUrl = `https:${data.current.condition.icon}`;
    const windSpeed = data.current.wind_kph;
    const humidity = data.current.humidity;
    const weatherDescription = data.current.condition.text;

    weatherInfo.innerHTML = `
        <tr>
            <td>${locationName}</td>
            <td>${country}</td>
            <td>${localTime}</td>
            <td>${currentTemp}</td>
            <td>${feelsLike}</td>
            <td>${forecastTemp}</td>
            <td>${sunrise}</td>
            <td>${sunset}</td>
            <td><img src="${iconUrl}" alt="${weatherDescription}" width="50" height="50"></td>
            <td>${windSpeed}</td>
            <td>${humidity}</td>
            <td>${weatherDescription}</td>
        </tr>
    `;
}

function displayTravelRecommendations(data) {
    const recommendations = document.getElementById('travel-recommendations');
    const currentTemp = data.current.temp_c;
    const condition = data.current.condition.text.toLowerCase();
    
    let activities = [];

    
    if (condition.includes('sunny') || condition.includes('clear')) {
        activities.push(
            "Relax on a beach with stunning views",
            "Take a boat tour or snorkeling trip",
            "Explore historical sites and landmarks",
            "Dine outdoors at a local seaside restaurant",
            "Visit popular scenic viewpoints for photography"
        );
    } else if (condition.includes('rain') || condition.includes('drizzle')) {
        activities.push(
            "Visit a local art museum or historical exhibit",
            "Enjoy a cooking class to learn regional cuisine",
            "Explore indoor markets and boutiques",
            "Book a wine or whiskey tasting tour",
            "Relax in a spa or wellness center"
        );
    } else if (condition.includes('snow')) {
        activities.push(
            "Go skiing or snowboarding on nearby slopes",
            "Take a scenic winter hike or sleigh ride",
            "Warm up with a hot drink in a cozy café",
            "Visit a holiday market for souvenirs",
            "Explore indoor attractions like historic castles"
        );
    } else if (currentTemp < 10) {
        activities.push(
            "Try a local hot spring or spa for relaxation",
            "Visit indoor historical sites like cathedrals or palaces",
            "Take a culinary tour of warm comfort foods",
            "Visit an aquarium or indoor botanical garden",
            "Catch a live performance or local theater show"
        );
    } else {
        activities.push(
            "Book a city tour or food-tasting walk",
            "Explore nearby islands or beaches by ferry",
            "Attend a local festival or cultural event",
            "Take a scenic bike ride along the coast",
            "Sample the best local seafood or cuisine"
        );
    }

    
    recommendations.innerHTML = `<h3>Recommended Holiday Activities</h3><ul>${activities.map(activity => `<li>${activity}</li>`).join('')}</ul>`;
}


var btnCreate = document.getElementById('btnCreate');
var btnRead = document.getElementById('btnRead');
var btnDelete = document.getElementById('btnDelete');
var btnUpdate = document.getElementById('btnUpdate'); 
var fileName = document.getElementById('fileName');
var fileContents = document.getElementById('fileContents');

// New elements to display file name and contents
var displayFileName = document.getElementById('displayFileName');
var displayFileContents = document.getElementById('displayFileContents');
var fileList = document.getElementById('fileList');  

let pathName = path.join(__dirname, 'Files');

// Function to update file list
function updateFileList() {
  fs.readdir(pathName, function (err, files) {
    if (err) {
      return console.log("Unable to scan directory: " + err);
    }
    fileList.innerHTML = "";  
    files.forEach(function (file) {
      let listItem = document.createElement('li');
      listItem.textContent = file;
      fileList.appendChild(listItem);
    });
  });
}

// Create file
btnCreate.addEventListener('click', function () {
  let file = path.join(pathName, fileName.value.endsWith('.txt') ? fileName.value : fileName.value + '.txt');
  let contents = fileContents.value;
  fs.writeFile(file, contents, function (err) {
    if (err) {
      return console.log(err);
    }
    updateFileList();  
  });
});

// Read file
btnRead.addEventListener('click', function () {
  let file = path.join(pathName, fileName.value.endsWith('.txt') ? fileName.value : fileName.value + '.txt');
  fs.readFile(file, 'utf8', function (err, data) {
    if (err) {
      return console.log(err);
    }
    fileContents.value = data;  
    displayFileName.textContent = fileName.value;  
    displayFileContents.textContent = data;          
  });
});

// Delete file
btnDelete.addEventListener('click', function () {
  let file = path.join(pathName, fileName.value.endsWith('.txt') ? fileName.value : fileName.value + '.txt');
  fs.unlink(file, function (err) {
    if (err) {
      return console.log(err);
    }
    fileName.value = "";
    fileContents.value = "";
    displayFileName.textContent = "";  
    displayFileContents.textContent = ""; 
    updateFileList();  
  });
});

// Update file
btnUpdate.addEventListener('click', function () {
  let file = path.join(pathName, fileName.value.endsWith('.txt') ? fileName.value : fileName.value + '.txt');
  let updatedContents = fileContents.value;

  fs.writeFile(file, updatedContents, function (err) {
    if (err) {
      return console.log(err);
    }
    displayFileName.textContent = fileName.value;  
    displayFileContents.textContent = updatedContents; 
    updateFileList();
  });
});


updateFileList();
