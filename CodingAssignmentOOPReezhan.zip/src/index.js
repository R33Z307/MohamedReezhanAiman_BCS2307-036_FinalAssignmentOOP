const { app, BrowserWindow, Menu } = require('electron');
const path = require('node:path');

// Handle creating/removing shortcuts on Windows when installing/uninstalling.
if (require('electron-squirrel-startup')) {
  app.quit();
}

let mainWindow;

const createWindow = () => {
  // Create the browser window.
  mainWindow = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: true,
      contextIsolation: false,

    },
  });

  // Load the initial page.
  mainWindow.loadFile(path.join(__dirname, 'home.html'));

  // Open the DevTools.
  mainWindow.webContents.openDevTools();
};

// Menu template for navigation
const menuTemplate = [
  {
    label: 'File',
    submenu: [
      {
        label: 'HOME',
        click: () => {
          mainWindow.loadFile(path.join(__dirname, 'home.html'));
        },
      },
      {
        label: 'WHAT TO BRING',
        click: () => {
          mainWindow.loadFile(path.join(__dirname, 'pack.html'));
        },
      },
      {
        label: 'WHAT TO DO',
        click: () => {
          mainWindow.loadFile(path.join(__dirname, 'todo.html'));
        },
      },
      {
        role: 'quit',
      },
    ],
  },
];

const menu = Menu.buildFromTemplate(menuTemplate);
Menu.setApplicationMenu(menu);

// This method will be called when Electron has finished
// initialization and is ready to create browser windows.
app.whenReady().then(() => {
  createWindow();
  

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});
