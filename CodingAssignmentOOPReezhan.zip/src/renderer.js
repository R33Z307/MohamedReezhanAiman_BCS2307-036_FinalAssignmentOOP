const apiKey = '32804b24a847407391c53709241010'; 
// https://api.weatherapi.com/v1/forecast.json?key=32804b24a847407391c53709241010&q=London
document.getElementById('fetch-weather-btn').addEventListener('click', fetchWeatherData);

async function fetchWeatherData() {
    const location = document.getElementById('location-input').value; 
    if (!location) {
        alert('Please enter a location');
        return;
    }

    const response = await fetch(`https://api.weatherapi.com/v1/forecast.json?key=${apiKey}&q=${location}`);
    const data = await response.json();
    displayWeatherData(data);
}

function displayWeatherData(data) {
    const weatherInfo = document.getElementById('weather-info');

    if (data.error) {
        weatherInfo.innerHTML = `<tr><td colspan="13">Error: ${data.error.message}</td></tr>`;
        return;
    }

    const locationName = data.location.name;
    const country = data.location.country;
    
    
    const localTime = data.location.localtime;

    const currentTemp = data.current.temp_c;
    const feelsLike = data.current.feelslike_c;
    const forecastTemp = `${data.current.temp_c}°C`; 
    const sunrise = data.forecast.forecastday[0].astro.sunrise;
    const sunset = data.forecast.forecastday[0].astro.sunset;
    const icon = data.current.condition.icon; 
    const iconUrl = `https:${icon}`;
    const windSpeed = data.current.wind_kph;
    const humidity = data.current.humidity;
    const weatherDescription = data.current.condition.text;

    weatherInfo.innerHTML = `
        <tr>
            <td>${locationName}</td>
            <td>${country}</td>
            <td>${localTime}</td>
            <td>${currentTemp}</td>
            <td>${feelsLike}</td>
            <td>${forecastTemp}</td>
            <td>${sunrise}</td>
            <td>${sunset}</td>
            <td><img src="${iconUrl}" alt="${weatherDescription}" width="50" height="50"></td>
            <td>${windSpeed}</td>
            <td>${humidity}</td>
            <td>${weatherDescription}</td>
        </tr>
    `;

}

